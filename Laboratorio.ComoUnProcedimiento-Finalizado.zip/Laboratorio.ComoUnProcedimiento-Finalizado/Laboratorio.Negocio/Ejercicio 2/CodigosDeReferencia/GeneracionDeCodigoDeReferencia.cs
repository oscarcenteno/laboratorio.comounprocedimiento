﻿using System;

namespace Laboratorio1.Negocio.Ejercicio2.CodigosDeReferencia
{
    public static class GeneracionDeCodigoDeReferencia
    {
        public static string GenereElCodigoDeReferencia(System.DateTime laFecha, short elCliente, short elSistema, string elConsecutivo, string elDigito)
        {

            int elAno = laFecha.Year;
            string elAnoComoTexto = elAno.ToString("D4");

            int elMes;
            elMes = laFecha.Month;
            string elMesComoTexto = elMes.ToString("D2");

            int elDia;
            elDia = laFecha.Day;
            string elDiaComoTexto = elDia.ToString("D2");

            string laFechaComoTexto = elAnoComoTexto + elMesComoTexto + elDiaComoTexto;
            string elClienteComoTexto = elCliente.ToString("D3");
            string elSistemaComoTexto = elSistema.ToString("D2");
            string elConsecutivoAjustado = elConsecutivo.PadLeft(12, '0');

            string elRequerimiento;
            elRequerimiento = laFechaComoTexto + elClienteComoTexto + elSistemaComoTexto + elConsecutivoAjustado;

            return elRequerimiento + elDigito;
        }
    }
}