﻿using System;

namespace Laboratorio1.Negocio.Ejercicio3.CodigosDeReferencia
{
    public static class GeneracionDeCodigoDeReferencia
    {
        public static string GenereElCodigoDeReferencia(DateTime laFecha, short elCliente, short elSistema, string elConsecutivo, string elDigito)
        {
            int elDia = laFecha.Day;
            string elDiaComoTexto = elDia.ToString("D2");

            int elMes = laFecha.Month;
            string elMesComoTexto = elMes.ToString("D2");

            var elAño = laFecha.Year;
            var elAñoComoTexto = elAño.ToString("D4");

            string laFechaComoTexto = elAñoComoTexto + elMesComoTexto + elDiaComoTexto;
            string elSistemaComoTexto = elSistema.ToString("D2");
            string elConsecutivoAjustado = elConsecutivo.PadLeft(12, '0');

            string elRequerimiento;
            elRequerimiento = laFechaComoTexto + elCliente.ToString("D3") + elSistemaComoTexto + elConsecutivoAjustado;

            return elRequerimiento + elDigito;
        }
    }
}