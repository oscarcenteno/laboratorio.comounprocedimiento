﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio1.Negocio.Ejercicio3.Valoraciones
{
    public enum Monedas
    {
        Colon,
        USDolar,
        UDEs
    }
}
