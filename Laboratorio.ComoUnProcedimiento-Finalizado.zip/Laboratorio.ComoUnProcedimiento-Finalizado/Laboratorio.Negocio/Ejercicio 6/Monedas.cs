﻿namespace Laboratorio.Negocio.Ejercicio6
{
    public enum Monedas
    {
        UDES,
        Colon,
        Dolar
    }
}
