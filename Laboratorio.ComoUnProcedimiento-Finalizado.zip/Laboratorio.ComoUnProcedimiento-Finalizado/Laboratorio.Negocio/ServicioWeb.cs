﻿namespace Laboratorio1.Negocio
{
    internal class ServicioWeb
    {
    }
}