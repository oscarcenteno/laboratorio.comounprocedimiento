﻿namespace Laboratorio1.Negocio.Ejercicio1.Valoraciones
{
    public enum Monedas
    {
        Colon,
        USDolar,
        UDEs
    }
}
